plugin.audio.musicbox
=====================

Music box is a new way to listen and discover music thought KODI (former XBMC)

Addon Repository: https://techdealerrepo.svn.codeplex.com/svn/repository.techdealer-1.0.2.zip
